---
title: OpenTenBase HNSW 冻结快照只读审查
status: 完成
date: 2026-09-04
tags: [opentenbase, hnsw, review, evidence, reproducibility]
---

# OpenTenBase HNSW 冻结快照只读审查

## 结论

对当前 C 补丁、Python 实验工具、参数/规模 raw evidence 和报告口径完成独立的
AI 辅助只读交叉审查。修正审查中暴露的协议与表述问题后，最终快照没有发现
P0、P1、P2 或新增 P3 问题，可以进入负责人/维护者人类 Review 与交付准备。

本页不是维护者签字，也不能替代人类代码 Review；审查过程没有 commit、push、
PR、清理结果或修改冻结 C diff。

## 冻结身份

| 对象 | 身份 |
|---|---|
| pgvector 4 文件 binary diff | `eb09370a414afda75eb7550f21d12f118d1d6f1b32ff0a46ecf1c4ec3bb7e50f` |
| 参数汇总器 | `a319275c1463ea42bcdaae23a4df3fb696b36f806510755c0683b91f5fbd5677` |
| 最终 `run.py` | `18d31610af4efc6c652c2453b153b9dd8f63b8ae9e80bbb3f50aa93267cfbcef` |
| 最终 `recall.py` | `8fed0edf184dfb9375f9038f60a5e04ce9e5c9ef167f87d4b10ba920e7e0fb89` |
| `dev/compose.yml` | `e348f673186e72e472aad3abc7f8c7a1950fb92fb5918eb4161367a4aca8304e` |

`git diff --check` 通过，OpenTenBase checkout 保持 clean。C diff 与此前通过
Debian/CentOS 全量回归时完全相同，因此本次只读终检引用已归档的 27/411 TAP、
4/4 SQL regression 和专项 5/5，不把它们冒充 9 月 4 日重新执行。

## 代码与工具复核

- C：原子阶段只前进，parallel worker 只更新共享状态并唤醒 leader；leader 在
  DSM 销毁前完成读取，WAL 阶段不再解引用共享图；未发现并发或生命周期阻断项；
- Python：`py_compile` 通过，`unittest discover` 28/28 通过；参数汇总器会拒绝
  重复 source，以及混合采样间隔、宿主/版本、距离/分布、镜像和 checkout 身份；
- r4：`20260903T112623Z-final-tooling-provenance-spill-smoke-r4` 实际启动 2 个
  worker、触发 spill，验证 Exact `Seq Scan` 与目标 HNSW，并正确解释 1MiB
  parallel allocation safety margin；记录的三个工具/Compose 哈希与磁盘一致。

## 机器证据反算

### 参数矩阵

- 从 14 个唯一 raw `summary.json` 重新聚合，与现有
  `20260903-parameter-sweep.json` 逐字段相同；
- 全部为 0.2 秒采样、PASS、Exact 顺序扫描和 HNSW 路径；
- 工作负载明确为 Euclidean L2、`vector_l2_ops`/`<->`，索引数据和独立 holdout
  均为逐维 synthetic uniform `[0,1)`。

### 规模关系

- 三张表共有 12 个引用、10 个唯一 raw run，全部正式采用点均为 0.2 秒采样；
- 采用字段全部反查一致；早期三个未解析的测试宏内存值另从 stderr 复核；
- 统一补跑后的 300k/500k/1M 分别为 `60.953895s`、`110.278092s`、
  `247.055756s`；1M 图内存为 `969,932,800` 字节（宏向下截断显示 925MiB），
  索引为 `570,105,856` 字节。

## 已披露而非隐藏的边界

- 14 个历史参数 run 没有序列化当时 Python 工具哈希，当前 r4 不能反向补记；
- 历史 source 字段描述运行时宿主 checkout，不是 Docker build-source
  attestation；baseline/candidate 主要依赖固定 image ID、构建留痕与行为证据；
- scale 每个点只有一次固定 seed，时间只作趋势，不作显著性或生产吞吐结论；
- scale JSON 是人工整理的机器可读派生表，但采用字段已逐项回查 raw evidence；
- `HNSW_MEMORY` 用整数除法向下截断到整 MiB；容器 `memory.current` 仍只是近似；
- 轮询可能漏掉短阶段，查询计时也没有随机化 ef 顺序或清空缓存。

## 下一门槛

1. 负责人或维护者做人类 Review；
2. 确认外置 pgvector 补丁、OpenTenBase 目标目录和提交入口；
3. 按确认后的目标形态 clean rebuild 并复跑专项回归；
4. 用户明确开始交付后再 commit、push 或创建 PR。

